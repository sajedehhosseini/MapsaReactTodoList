import React from 'react'

export default function ShowTime() {
    return (
        <div>
            <div className='pt-1 ml-3 text-success h5'>
                <i className='fa fa-clock'></i> date  00:00
            </div>
        </div>
    )
}
