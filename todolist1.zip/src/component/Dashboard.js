import React, { Component } from 'react'
import ShowTask from './ShowTask'
import SearchTask from './SearchTask'
export default class Dashboard extends Component {
    constructor(props) {
        super(props)
        this.state = {
            text: '',
            tasks: [{
                id:13981252100,
                title: 'task1',
                editflg: false,
                done: false

            }],
            editflg: false
        }
        console.log(this.state);
        
        this.newinput = React.createRef();
        this.editinput = React.createRef();

    }
    addTask = () => {
        const val = this.myRef.current.value;
        console.log(val);

    }
    searchTask=()=> {
        const val = this.myRef.current.value;
        console.log(val);
        // <SearchTask/>
    }
    editTask() {
        console.log('edit done');

    }
    deleteTask() {
        console.log('delete done');

    }
    doneTask() {
        console.log('done done');

    }
    newEditInput(){
        console.log('edit');
        
    }
    updateTask(){
        console.log('update');

    }
    render() {
        return (
            <>
                <div className='row h1'>
                    <>
                        TodoList
                   </>
                </div>
                <div className='row'>
                    <div className='col-10'>
                        <div className="input-group ">
                            <input type="text" className="form-control border-success pr-5 pl-5" placeholder="" ref={this.myRef} aria-label="Recipient's username" aria-describedby="basic-addon2" />
                            <div className="input-group-append">
                                <button className="btn btn-success pr-5 pl-5" type="button" onClick={this.addTask}>Add</button>
                                <button className="btn btn-success pr-5 pl-5" type="button" onClick={this.searchTask}>Search</button>
                            </div>
                        </div>
                    </div>
                    <div className='pt-1 ml-3 text-success h5'>
                    <i className='fa fa-clock'></i> date  00:00
                    </div>

                </div>
                <div className='row h2 d-flex flex-column p-3'>
                    <div className='border-bottom pl-5 pb-3 mb-2'>
                        <i className='mr-3 fa fa-tasks'></i>
                        Tasks (?)
                    </div>
                    {/* <hr /> */}
                    <>
                        <ShowTask title='title' editflg={false} handledone={this.doneTask} handledel={this.deleteTask} handleedit={this.editTask} handleupdate={this.updateTask}/>
                    </>
                </div>
                <div className='row h2 d-flex flex-column p-3'>
                    <div className='border-bottom pl-5 pb-3 mb-2'>
                        <i className='mr-3 fa fa-tasks'></i>
                        Done Tasks (?)
                    </div>
                    {/* <hr /> */}
                    <>
                        <ShowTask title='title' editflg={true} handledone={this.doneTask} handledel={this.deleteTask} handleedit={this.editTask} handleupdate={this.updateTask}/>
                    </>
                </div>
            </>
        )
    }
}
