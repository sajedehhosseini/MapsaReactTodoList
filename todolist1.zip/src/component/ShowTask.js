import React from 'react'

export default function ShowTask(props) {
    console.log(props);
    props.editflg && console.log(props.editflg)
    props.editflg || console.log('false')

    return (
        <div>
            <div className="input-group mb-3">
                <div className="input-group-prepend">
                    <div className="input-group-text bg-success border-success">
                        <input type="checkbox" aria-label="Checkbox for following text input" onClick={props.handledone} />
                    </div>
                </div>
                {props.editflg && <><button className="btn btn-success pr-3 pl-3 rounded-0" type="button" onClick={props.handleupdate}><i className='fa fa-send'></i></button>
                <button className="btn btn-success pr-3 pl-3 rounded-0" type="button" onClick={props.handleupdate}><i className='fa fa-times'></i></button><input type="text" className="form-control border-right-0 border-success border-left-0 pl-5" aria-label="Text input with checkbox" placeholder={props.title} />
                </>
                }
                {props.editflg || <label className="form-control border-right-0 border-success border-left-0 pl-5" aria-label="Text input with checkbox" >{props.title}</label>
                }
                <div className="input-group-prepend">
                    <span className="input-group-text bg-light border-top border-bottom  border-left-0 border-success pl-5 pr-5">create date</span>
                    <button className="btn btn-success pr-4 pl-4" type="button" onClick={props.handleedit}><i className='fa fa-edit'></i></button>
                    <button className="btn btn-success pr-4 pl-4 rounded-right" type="button" onClick={props.handledel}><i className='fa fa-trash'></i></button>
                </div>
            </div>

        </div>
    )
}
