import React from 'react'

export default function SearchTask(props) {
    console.log(props);
    
}
