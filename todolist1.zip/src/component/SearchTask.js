import React from 'react'

export default function SearchTask() {
    return (
        <div>
            search done
        </div>
    )
}
