import React from 'react';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'font-awesome/css/font-awesome.min.css';
import Dashboard from './component/Dashboard'

function App() {
  return (
 <div className='container p-5'>
 <Dashboard/>
 </div>
  );
}

export default App;
